"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.APP_MASTER_HWID = exports.APP_MASTER_KEY = void 0;
exports.deriveKey = deriveKey;
exports.encryptData = encryptData;
exports.decryptData = decryptData;
exports.encryptFile = encryptFile;
exports.decryptFile = decryptFile;
const crypto_1 = __importDefault(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
exports.APP_MASTER_KEY = 'SUBGAME_ASSET_PROTECTION_2026_MASTER_SECRET_KEY';
exports.APP_MASTER_HWID = 'SUBGAME_SYSTEM_HWID_BINDING';
const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12; // 96 bits for GCM
const AUTH_TAG_LENGTH = 16;
const SALT_LENGTH = 16;
/**
 * Derives a 256-bit key using PBKDF2 from a master secret and the machine HWID
 */
function deriveKey(licenseKey = exports.APP_MASTER_KEY, hwid = exports.APP_MASTER_HWID, salt) {
    const secret = `${licenseKey}::SUBGAME_PROTECTION::${hwid}`;
    return crypto_1.default.pbkdf2Sync(secret, salt, 100000, 32, 'sha256');
}
/**
 * Encrypts a buffer or file content
 */
function encryptData(data, licenseKey = exports.APP_MASTER_KEY, hwid = exports.APP_MASTER_HWID) {
    const salt = crypto_1.default.randomBytes(SALT_LENGTH);
    const iv = crypto_1.default.randomBytes(IV_LENGTH);
    const key = deriveKey(licenseKey, hwid, salt);
    const cipher = crypto_1.default.createCipheriv(ALGORITHM, key, iv);
    const encrypted = Buffer.concat([cipher.update(data), cipher.final()]);
    const tag = cipher.getAuthTag();
    // File structure: [SALT (16)] + [IV (12)] + [TAG (16)] + [CIPHERTEXT]
    return Buffer.concat([salt, iv, tag, encrypted]);
}
/**
 * Decrypts a previously encrypted buffer
 */
function decryptData(encryptedBuffer, licenseKey = exports.APP_MASTER_KEY, hwid = exports.APP_MASTER_HWID) {
    if (encryptedBuffer.length < SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH) {
        throw new Error('Noto\'g\'ri shifrlangan fayl formati');
    }
    const salt = encryptedBuffer.subarray(0, SALT_LENGTH);
    const iv = encryptedBuffer.subarray(SALT_LENGTH, SALT_LENGTH + IV_LENGTH);
    const tag = encryptedBuffer.subarray(SALT_LENGTH + IV_LENGTH, SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH);
    const ciphertext = encryptedBuffer.subarray(SALT_LENGTH + IV_LENGTH + AUTH_TAG_LENGTH);
    const key = deriveKey(licenseKey, hwid, salt);
    const decipher = crypto_1.default.createDecipheriv(ALGORITHM, key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ciphertext), decipher.final()]);
}
/**
 * Encrypts a source file (e.g. tt01.pc) to a target encrypted file (.enc)
 */
function encryptFile(srcPath, destPath, licenseKey = exports.APP_MASTER_KEY, hwid = exports.APP_MASTER_HWID) {
    const fileData = fs_1.default.readFileSync(srcPath);
    const encrypted = encryptData(fileData, licenseKey, hwid);
    fs_1.default.mkdirSync(path_1.default.dirname(destPath), { recursive: true });
    fs_1.default.writeFileSync(destPath, encrypted);
}
/**
 * Decrypts an encrypted file to memory or temporary destination
 */
function decryptFile(srcPath, destPath, licenseKey = exports.APP_MASTER_KEY, hwid = exports.APP_MASTER_HWID) {
    const encryptedData = fs_1.default.readFileSync(srcPath);
    const decrypted = decryptData(encryptedData, licenseKey, hwid);
    fs_1.default.mkdirSync(path_1.default.dirname(destPath), { recursive: true });
    fs_1.default.writeFileSync(destPath, decrypted);
}
