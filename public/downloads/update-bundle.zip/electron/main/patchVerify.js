"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.compareSemver = compareSemver;
exports.verifyPatchDir = verifyPatchDir;
exports.readBlockedPatchVersions = readBlockedPatchVersions;
exports.blockPatchVersion = blockPatchVersion;
const crypto_1 = __importDefault(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Launcher patchlarini imzolovchi kalitning ochiq qismi (ed25519, SPKI DER, base64).
 * Yopiq kalit repoda saqlanmaydi: %USERPROFILE%\.subgame\launcher-patch-key.pem
 * (scripts/create-patch.js shu bilan imzolaydi).
 */
const PATCH_PUBLIC_KEY = 'MCowBQYDK2VwAyEAdimS/cM9vECTmJi/nZ3ZyI2BQoaS4c0DTCtWwXPrss4=';
function compareSemver(a, b) {
    const pa = String(a).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
    const pb = String(b).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        if ((pa[i] || 0) !== (pb[i] || 0))
            return (pa[i] || 0) > (pb[i] || 0) ? 1 : -1;
    }
    return 0;
}
function listFiles(dir, base = dir) {
    if (!fs_1.default.existsSync(dir))
        return [];
    const out = [];
    for (const entry of fs_1.default.readdirSync(dir, { withFileTypes: true })) {
        const full = path_1.default.join(dir, entry.name);
        if (entry.isDirectory())
            out.push(...listFiles(full, base));
        else
            out.push(path_1.default.relative(base, full).split(path_1.default.sep).join('/'));
    }
    return out;
}
/**
 * Patch papkasini tekshiradi: manifest.json imzosi ochiq kalitga mos kelishi, ro'yxatdagi har bir
 * faylning sha256 si to'g'ri bo'lishi va electron/ ichida ro'yxatda yo'q fayl bo'lmasligi kerak.
 * Mos kelmasa sababini aytib xato tashlaydi.
 */
function verifyPatchDir(dir) {
    const manifestPath = path_1.default.join(dir, 'manifest.json');
    const sigPath = path_1.default.join(dir, 'manifest.sig');
    if (!fs_1.default.existsSync(manifestPath) || !fs_1.default.existsSync(sigPath)) {
        throw new Error('patch is not signed');
    }
    const manifestBuf = fs_1.default.readFileSync(manifestPath);
    const signature = Buffer.from(fs_1.default.readFileSync(sigPath, 'utf8').trim(), 'base64');
    const publicKey = crypto_1.default.createPublicKey({
        key: Buffer.from(PATCH_PUBLIC_KEY, 'base64'),
        format: 'der',
        type: 'spki',
    });
    if (!crypto_1.default.verify(null, manifestBuf, publicKey, signature)) {
        throw new Error('bad patch signature');
    }
    const manifest = JSON.parse(manifestBuf.toString('utf8'));
    if (!manifest || typeof manifest.version !== 'string' || !manifest.files) {
        throw new Error('bad patch manifest');
    }
    const root = path_1.default.resolve(dir);
    for (const [rel, hash] of Object.entries(manifest.files)) {
        const full = path_1.default.resolve(root, rel);
        if (!full.startsWith(root + path_1.default.sep))
            throw new Error(`bad path in manifest: ${rel}`);
        if (!fs_1.default.existsSync(full))
            throw new Error(`missing patch file: ${rel}`);
        const actual = crypto_1.default.createHash('sha256').update(fs_1.default.readFileSync(full)).digest('hex');
        if (actual !== hash)
            throw new Error(`patch file changed: ${rel}`);
    }
    for (const rel of listFiles(path_1.default.join(root, 'electron'), root)) {
        if (!(rel in manifest.files))
            throw new Error(`unlisted patch file: ${rel}`);
    }
    const versionFile = path_1.default.join(root, 'version.json');
    const declared = fs_1.default.existsSync(versionFile) ? JSON.parse(fs_1.default.readFileSync(versionFile, 'utf8'))?.version : null;
    if (declared !== manifest.version)
        throw new Error('patch version mismatch');
    return manifest;
}
/** Ishlamay qolgan patch versiyalari: launcher ularni qayta o'rnatmaydi, to'liq yangilanishni oladi. */
function readBlockedPatchVersions(userData) {
    try {
        const list = JSON.parse(fs_1.default.readFileSync(path_1.default.join(userData, 'patch-blocklist.json'), 'utf8'));
        return Array.isArray(list) ? list.map(String) : [];
    }
    catch {
        return [];
    }
}
function blockPatchVersion(userData, version) {
    if (!version)
        return;
    const list = readBlockedPatchVersions(userData);
    if (list.includes(version))
        return;
    list.push(version);
    try {
        fs_1.default.writeFileSync(path_1.default.join(userData, 'patch-blocklist.json'), JSON.stringify(list));
    }
    catch { }
}
