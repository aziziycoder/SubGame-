"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSubtitleRemovalInfo = getSubtitleRemovalInfo;
exports.removeSubtitles = removeSubtitles;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const electron_1 = require("electron");
const crypto_1 = require("./crypto");
const rangePatch_1 = require("./rangePatch");
const gameRunner_1 = require("./gameRunner");
function userCacheDir(gameId) {
    return path_1.default.join(electron_1.app.getPath('userData'), 'subtitles', gameId);
}
function isSafeGameId(gameId) {
    return typeof gameId === 'string' && /^[a-z0-9][a-z0-9._-]*$/i.test(gameId) && !gameId.includes('..');
}
function fileSize(p) {
    try {
        return fs_1.default.statSync(p).size;
    }
    catch {
        return 0;
    }
}
function dirSize(dir) {
    let total = 0;
    try {
        for (const e of fs_1.default.readdirSync(dir, { withFileTypes: true })) {
            const full = path_1.default.join(dir, e.name);
            total += e.isDirectory() ? dirSize(full) : fileSize(full);
        }
    }
    catch { }
    return total;
}
function listFilesRel(dir, base = dir) {
    try {
        return fs_1.default.readdirSync(dir, { withFileTypes: true }).flatMap((e) => {
            const full = path_1.default.join(dir, e.name);
            return e.isDirectory() ? listFilesRel(full, base) : [path_1.default.relative(base, full)];
        });
    }
    catch {
        return [];
    }
}
/** injectSubtitleFile dagi maqsad papka bilan bir xil, lekin hech qanday papka yaratmaydi */
function findTargetDir(gameDir, targetRelativeDir) {
    if (targetRelativeDir) {
        const candidates = [
            path_1.default.join(gameDir, targetRelativeDir),
            path_1.default.resolve(gameDir, '../../..', targetRelativeDir),
            path_1.default.resolve(gameDir, '../..', targetRelativeDir),
            path_1.default.resolve(gameDir, '..', targetRelativeDir),
        ];
        const found = candidates.find((c) => fs_1.default.existsSync(c));
        if (found)
            return found;
    }
    if (fs_1.default.existsSync(path_1.default.join(gameDir, 'TRTEXT')))
        return path_1.default.join(gameDir, 'TRTEXT');
    if (targetRelativeDir)
        return path_1.default.join(gameDir, targetRelativeDir);
    return gameDir;
}
/** Paketimizdagi faylning o'yinga yoziladigan (dekodlangan) mazmuni; paket yo'q bo'lsa null */
function readOurPayload(gameId, fileName, fileNames) {
    let source = (0, gameRunner_1.findSubtitleSource)(gameId, fileName);
    if (!source) {
        const wantExt = path_1.default.extname(fileName).toLowerCase();
        for (const other of fileNames) {
            if (other === fileName || path_1.default.extname(other).toLowerCase() !== wantExt)
                continue;
            source = (0, gameRunner_1.findSubtitleSource)(gameId, other);
            if (source)
                break;
        }
    }
    if (!source)
        return null;
    try {
        const raw = fs_1.default.readFileSync(source.path);
        try {
            return (0, crypto_1.decryptData)(raw);
        }
        catch {
            return source.isEncrypted ? null : raw;
        }
    }
    catch {
        return null;
    }
}
/** Fayl band (o'yin ochiq) bo'lsa, uni "bizniki emas" deb jim o'tkazib yubormaslik uchun xatoni uzatamiz */
class FileLockedError extends Error {
    code = 'EBUSY';
}
function rethrowIfLocked(err) {
    if (err?.code === 'EBUSY' || err?.code === 'EPERM' || err?.code === 'EACCES') {
        throw new FileLockedError(String(err?.message || err));
    }
}
function sameContent(file, data) {
    try {
        if (fs_1.default.statSync(file).size !== data.length)
            return false;
        return fs_1.default.readFileSync(file).equals(data);
    }
    catch (err) {
        rethrowIfLocked(err);
        return false;
    }
}
function filesEqual(a, b) {
    try {
        if (fs_1.default.statSync(a).size !== fs_1.default.statSync(b).size)
            return false;
        return fs_1.default.readFileSync(a).equals(fs_1.default.readFileSync(b));
    }
    catch (err) {
        rethrowIfLocked(err);
        return false;
    }
}
/** Range patch: fayl hozir to'liq bizning baytlarimiz bilan patchlanganmi */
function isRangeApplied(file, patch) {
    try {
        const parsed = (0, rangePatch_1.parseRangePatch)(patch);
        if (fs_1.default.statSync(file).size !== parsed.targetSize)
            return false;
        const fd = fs_1.default.openSync(file, 'r');
        try {
            for (const e of parsed.entries) {
                const cur = Buffer.alloc(e.data.length);
                fs_1.default.readSync(fd, cur, 0, e.data.length, e.offset);
                if (!cur.equals(e.data))
                    return false;
            }
            return true;
        }
        finally {
            fs_1.default.closeSync(fd);
        }
    }
    catch (err) {
        rethrowIfLocked(err);
        return false;
    }
}
function planGameFolder(config, gameDir) {
    const actions = [];
    const destDir = findTargetDir(gameDir, config.targetRelativeDir);
    if (!fs_1.default.existsSync(destDir))
        return actions;
    const fileNames = (0, gameRunner_1.resolveSubtitleFileNames)(config, destDir);
    // Avvalgi launcher xatosidan qolgan noto'g'ri nomli fayl (faqat launcher yaratgan)
    const junk = path_1.default.join(destDir, 'stringtable_en.sds,stringtable_ru.sds');
    if (fs_1.default.existsSync(junk))
        actions.push({ kind: 'delete-added', target: junk, bytes: fileSize(junk) });
    for (const name of fileNames) {
        const dest = path_1.default.join(destDir, name);
        if (path_1.default.resolve(dest).toLowerCase() === path_1.default.resolve(config.gameExePath).toLowerCase())
            continue;
        const bak = path_1.default.join(destDir, `${name}.subgame_bak`);
        const rangeBak = `${dest}.subgame_rangebak`;
        const payload = readOurPayload(config.gameId, name, fileNames);
        if (fs_1.default.existsSync(rangeBak)) {
            actions.push({ kind: 'restore-range', target: dest, backup: rangeBak, bytes: fileSize(rangeBak) });
            continue;
        }
        if (payload && (0, rangePatch_1.isRangePatch)(payload)) {
            // Zaxirasiz, lekin fayl hali patchlangan: asl baytlarni qaytara olmaymiz
            if (fs_1.default.existsSync(dest) && isRangeApplied(dest, payload)) {
                actions.push({ kind: 'restore-range', target: dest, bytes: 0, needsVerify: true });
            }
            continue;
        }
        if (fs_1.default.existsSync(bak)) {
            if (fs_1.default.existsSync(dest) && filesEqual(dest, bak)) {
                actions.push({ kind: 'drop-backup', target: dest, backup: bak, bytes: fileSize(bak) });
            }
            else {
                actions.push({ kind: 'restore-backup', target: dest, backup: bak, bytes: fileSize(bak) });
            }
            continue;
        }
        // Zaxira yo'q: faqat mazmuni aynan bizning paketimiz bilan bir xil faylni o'chiramiz.
        // Asl fayl hech qachon bo'lmagan bo'lsa (masalan, qo'shimcha dll) o'yin buzilmaydi; aks holda
        // foydalanuvchiga o'yin fayllarini tekshirishni tavsiya qilamiz.
        if (payload && fs_1.default.existsSync(dest) && sameContent(dest, payload)) {
            actions.push({ kind: 'delete-added', target: dest, bytes: payload.length, needsVerify: true });
        }
    }
    // commonx (RDR2 fontmap): faqat biz tarqatgan va mazmuni o'zgarmagan fayllar
    const cacheExtra = [
        path_1.default.join(userCacheDir(config.gameId), gameRunner_1.EXTRA_GAME_DIR),
        ...(process.resourcesPath ? [path_1.default.join(process.resourcesPath, 'subtitles', config.gameId, gameRunner_1.EXTRA_GAME_DIR)] : []),
        path_1.default.join(electron_1.app.getAppPath(), 'public', 'subtitles', config.gameId, gameRunner_1.EXTRA_GAME_DIR),
    ].find((p) => {
        try {
            return fs_1.default.statSync(p).isDirectory();
        }
        catch {
            return false;
        }
    });
    if (cacheExtra) {
        const gameExtra = path_1.default.join(destDir, gameRunner_1.EXTRA_GAME_DIR);
        for (const rel of listFilesRel(cacheExtra)) {
            const inGame = path_1.default.join(gameExtra, rel);
            if (fs_1.default.existsSync(inGame) && filesEqual(inGame, path_1.default.join(cacheExtra, rel))) {
                actions.push({ kind: 'delete-extra', target: inGame, bytes: fileSize(inGame) });
            }
        }
    }
    return actions;
}
function gameIsRunning(config, gameDir) {
    if (gameRunner_1.activeSessions.has(config.gameId))
        return true;
    try {
        return (0, gameRunner_1.isProcessRunning)((0, gameRunner_1.resolveLaunchPlan)(config, gameDir).processPattern);
    }
    catch {
        return false;
    }
}
function folderState(config) {
    const exe = config.gameExePath || '';
    const gameDir = exe ? path_1.default.dirname(exe) : '';
    return { gameDir, found: !!exe && fs_1.default.existsSync(exe) };
}
function getSubtitleRemovalInfo(config) {
    const empty = {
        success: false,
        cacheBytes: 0,
        gameFolderBytes: 0,
        totalBytes: 0,
        gameFolderItems: 0,
        gameFolderFound: false,
        gameRunning: false,
        filesLocked: false,
        nothingToRemove: true,
        needsVerify: false,
    };
    try {
        if (!config || !isSafeGameId(config.gameId))
            return { ...empty, message: "O'yin aniqlanmadi." };
        const cacheBytes = dirSize(userCacheDir(config.gameId));
        const { gameDir, found } = folderState(config);
        let actions = [];
        let filesLocked = false;
        if (found) {
            try {
                actions = planGameFolder(config, gameDir);
            }
            catch (err) {
                if (!(err instanceof FileLockedError))
                    throw err;
                filesLocked = true;
            }
        }
        const gameFolderBytes = actions.reduce((s, a) => s + a.bytes, 0);
        const cacheExists = fs_1.default.existsSync(userCacheDir(config.gameId));
        return {
            success: true,
            cacheBytes,
            gameFolderBytes,
            totalBytes: cacheBytes + gameFolderBytes,
            gameFolderItems: actions.length,
            gameFolderFound: found,
            gameRunning: found ? gameIsRunning(config, gameDir) : gameRunner_1.activeSessions.has(config.gameId),
            filesLocked,
            nothingToRemove: !cacheExists && actions.length === 0 && !filesLocked,
            needsVerify: actions.some((a) => a.needsVerify),
        };
    }
    catch (err) {
        return { ...empty, message: `Ma'lumotni o'qib bo'lmadi: ${(0, gameRunner_1.hideFileDetails)(err)}` };
    }
}
function isLockError(err) {
    const code = err?.code;
    if (code === 'EBUSY' || code === 'EPERM' || code === 'EACCES')
        return true;
    return /EBUSY|EPERM|EACCES|ruxsat/i.test(String(err?.message || ''));
}
async function withRetry(fn, attempts = 3) {
    for (let i = 0;; i++) {
        try {
            fn();
            return;
        }
        catch (err) {
            if (i >= attempts - 1 || !isLockError(err))
                throw err;
            await new Promise((r) => setTimeout(r, 700));
        }
    }
}
function removeEmptyDirsUpTo(startDir, stopDir) {
    let dir = startDir;
    const stop = path_1.default.resolve(stopDir).toLowerCase();
    while (path_1.default.resolve(dir).toLowerCase().startsWith(stop)) {
        try {
            if (fs_1.default.readdirSync(dir).length > 0)
                return;
            fs_1.default.rmdirSync(dir);
        }
        catch {
            return;
        }
        if (path_1.default.resolve(dir).toLowerCase() === stop)
            return;
        dir = path_1.default.dirname(dir);
    }
}
/**
 * Subtitrlarni olib tashlaydi.
 * cacheOnly: o'yin papkasi topilmaganda foydalanuvchi faqat launcher yuklagan paketni o'chirishni tanlaydi.
 */
async function removeSubtitles(config, cacheOnly = false) {
    try {
        if (!config || !isSafeGameId(config.gameId)) {
            return { success: false, code: 'error', message: "O'yin aniqlanmadi." };
        }
        const { gameDir, found } = folderState(config);
        if (!found && !cacheOnly) {
            return {
                success: false,
                code: 'folder-missing',
                message: "O'yin papkasi topilmadi. O'yinni boshqa joyga ko'chirgan bo'lsangiz, avval yangi joydagi .exe faylini tanlang. O'yin o'chirilgan bo'lsa, faqat launcher yuklab olgan fayllarni o'chirishingiz mumkin.",
            };
        }
        if (found && gameIsRunning(config, gameDir)) {
            return {
                success: false,
                code: 'running',
                message: "O'yin hozir ochiq. Avval o'yinni to'liq yoping, keyin subtitrlarni o'chiring.",
            };
        }
        let freed = 0;
        let needsVerify = false;
        if (found && !cacheOnly) {
            try {
                const actions = planGameFolder(config, gameDir);
                for (const a of actions) {
                    switch (a.kind) {
                        case 'restore-backup':
                            await withRetry(() => {
                                (0, gameRunner_1.safeCopyFileSync)(a.backup, a.target);
                                fs_1.default.unlinkSync(a.backup);
                            });
                            break;
                        case 'drop-backup':
                            await withRetry(() => fs_1.default.unlinkSync(a.backup));
                            break;
                        case 'restore-range':
                            if (a.backup)
                                await withRetry(() => void (0, rangePatch_1.restoreRangePatch)(a.target, a.backup));
                            break;
                        case 'delete-added':
                            await withRetry(() => fs_1.default.unlinkSync(a.target));
                            break;
                        case 'delete-extra': {
                            await withRetry(() => fs_1.default.unlinkSync(a.target));
                            const marker = `${path_1.default.sep}${gameRunner_1.EXTRA_GAME_DIR}${path_1.default.sep}`;
                            const idx = a.target.toLowerCase().lastIndexOf(marker.toLowerCase());
                            if (idx >= 0) {
                                const root = a.target.slice(0, idx + marker.length - 1);
                                removeEmptyDirsUpTo(path_1.default.dirname(a.target), root);
                            }
                            break;
                        }
                    }
                    freed += a.bytes;
                    if (a.needsVerify)
                        needsVerify = true;
                }
            }
            catch (err) {
                if (isLockError(err)) {
                    return {
                        success: false,
                        code: 'locked',
                        message: "Ba'zi fayllar band: o'yin yoki boshqa dastur ularni ishlatmoqda. O'yinni (va Steam/Epic launcherini) yoping, keyin qaytadan urinib ko'ring.",
                    };
                }
                throw err;
            }
        }
        // Launcher yuklab olgan paket (o'yin papkasi tozalangandan keyin, aks holda qayta urinishda
        // qaysi fayl bizniki ekanini aniqlay olmay qolamiz)
        const cacheDir = userCacheDir(config.gameId);
        if (fs_1.default.existsSync(cacheDir)) {
            const bytes = dirSize(cacheDir);
            try {
                fs_1.default.rmSync(cacheDir, { recursive: true, force: true, maxRetries: 3, retryDelay: 300 });
            }
            catch (err) {
                if (isLockError(err)) {
                    return {
                        success: false,
                        code: 'locked',
                        message: "Launcher yuklab olgan fayllar band. Launcherni qayta ochib, yana urinib ko'ring.",
                    };
                }
                throw err;
            }
            freed += bytes;
        }
        const mb = (freed / (1024 * 1024)).toFixed(1);
        let message = found && !cacheOnly
            ? `O'zbekcha subtitrlar o'chirildi, o'yin asl holiga qaytarildi. ${mb} MB joy bo'shadi.`
            : `Launcher yuklab olgan o'zbekcha subtitr fayllari o'chirildi. ${mb} MB joy bo'shadi.`;
        if (needsVerify) {
            message +=
                " Agar o'yin ishga tushmasa yoki matnlar buzilsa, Steam/Epic'da o'yin fayllarini tekshiring (Verify integrity of game files).";
        }
        message += " Litsenziyangiz saqlanib qoldi: xohlasangiz istalgan vaqt qayta o'rnatishingiz mumkin.";
        return { success: true, message, freedBytes: freed, needsVerify };
    }
    catch (err) {
        return { success: false, code: 'error', message: `Subtitrlarni o'chirishda xatolik: ${(0, gameRunner_1.hideFileDetails)(err)}` };
    }
}
