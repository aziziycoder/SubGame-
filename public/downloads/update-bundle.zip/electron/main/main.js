"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const https_1 = __importDefault(require("https"));
const http_1 = __importDefault(require("http"));
const child_process_1 = require("child_process");
const hwid_1 = require("./hwid");
const license_1 = require("./license");
const gameRunner_1 = require("./gameRunner");
const patchVerify_1 = require("./patchVerify");
let mainWindow = null;
/**
 * To'liq (exe) yangilanishdan keyin userData/update ichida eski tez-yangilanish (UI patch) qolib ketsa,
 * launcher o'zini eski versiya deb ko'rsatadi va majburiy yangilanish cheksiz takrorlanadi.
 * Ilova versiyasidan eski bo'lgan UI patchni o'chirib tashlaymiz.
 */
function dropStaleUiPatch() {
    const updateDir = path_1.default.join(electron_1.app.getPath('userData'), 'update');
    const verFile = path_1.default.join(updateDir, 'dist', 'version.json');
    try {
        if (!fs_1.default.existsSync(verFile))
            return;
        const v = JSON.parse(fs_1.default.readFileSync(verFile, 'utf8'))?.version;
        if (!v || (0, patchVerify_1.compareSemver)(v, electron_1.app.getVersion()) < 0) {
            fs_1.default.rmSync(updateDir, { recursive: true, force: true });
        }
    }
    catch (err) {
        console.warn('Stale UI patch cleanup warning:', err);
    }
}
/** Portable launcher bo'lsa, foydalanuvchi ishga tushirgan asl .exe fayl yo'li */
function launcherExePath() {
    return process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
}
/**
 * 1.3.0 va undan eski launcherlar to'liq yangilanishni portable faylning o'rniga emas, %TEMP% dagi
 * vaqtinchalik nusxaga yozardi. Shunday ishga tushgan bo'lsak, o'zimizni ish stoliga saqlaymiz va
 * foydalanuvchiga bundan keyin shu fayldan ochishni aytamiz (aks holda eski fayl har safar yangilanish so'raydi).
 */
async function rescueFromTempLaunch() {
    try {
        const exe = process.env.PORTABLE_EXECUTABLE_FILE;
        if (!exe || !electron_1.app.isPackaged)
            return;
        const tmp = path_1.default.resolve(electron_1.app.getPath('temp')).toLowerCase();
        if (!path_1.default.resolve(exe).toLowerCase().startsWith(tmp))
            return;
        const desktopExe = path_1.default.join(electron_1.app.getPath('desktop'), 'SubGame Launcher.exe');
        if (path_1.default.resolve(desktopExe).toLowerCase() === path_1.default.resolve(exe).toLowerCase())
            return;
        fs_1.default.copyFileSync(exe, desktopExe);
        await electron_1.dialog.showMessageBox({
            type: 'info',
            title: 'SubGame Launcher yangilandi',
            message: `SubGame Launcher ${electron_1.app.getVersion()} ga yangilandi.`,
            detail: "Yangi launcher ish stolingizga \"SubGame Launcher.exe\" nomi bilan saqlandi. Bundan keyin launcherni shu fayldan oching. Eski launcher faylini o'chirib tashlashingiz mumkin.",
            buttons: ['Tushunarli'],
        });
    }
    catch (err) {
        console.warn('Temp launch rescue warning:', err);
    }
}
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        width: 1200,
        height: 780,
        minWidth: 1024,
        minHeight: 680,
        frame: false, // Frameless custom modern gaming UI
        backgroundColor: '#090d16',
        icon: path_1.default.join(electron_1.app.getAppPath(), 'dist', 'icon.ico'),
        webPreferences: {
            preload: path_1.default.join(__dirname, '../preload/preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
            sandbox: false,
        },
        title: 'SubGame Launcher',
    });
    const CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
    mainWindow.webContents.setUserAgent(CHROME_UA);
    // Handle Google OAuth Popups in Electron
    mainWindow.webContents.setWindowOpenHandler(({ url }) => {
        if (url.includes('accounts.google.com') || url.includes('oauth')) {
            return {
                action: 'allow',
                overrideBrowserWindowOptions: {
                    autoHideMenuBar: true,
                    width: 520,
                    height: 680,
                    webPreferences: {
                        nodeIntegration: false,
                        contextIsolation: true,
                    },
                },
            };
        }
        electron_1.shell.openExternal(url);
        return { action: 'deny' };
    });
    // Check if running in dev mode
    const isDev = process.env.NODE_ENV === 'development' || !electron_1.app.isPackaged;
    if (isDev && process.env.VITE_DEV_SERVER_URL) {
        mainWindow.loadURL(process.env.VITE_DEV_SERVER_URL);
    }
    else {
        // In production packaged app, check if a lightweight delta patch update exists in userData
        // exe ichidagi interfeys. app.getAppPath() ishlatiladi: main kod patchdan yuklanganda
        // __dirname userData ichini ko'rsatadi.
        const indexPath = path_1.default.join(electron_1.app.getAppPath(), 'dist', 'index.html');
        const userUpdateIndex = path_1.default.join(electron_1.app.getPath('userData'), 'update', 'dist', 'index.html');
        const patchesActive = electron_1.app.isPackaged || process.env.SUBGAME_DEV_PATCHES === '1';
        if (patchesActive && fs_1.default.existsSync(userUpdateIndex)) {
            mainWindow.loadFile(userUpdateIndex).catch((err) => {
                console.warn('Failed to load user update index, falling back to bundled:', err);
                mainWindow?.loadFile(indexPath);
            });
        }
        else {
            mainWindow.loadFile(indexPath);
        }
    }
    // Oyna ochildi: patchdan yuklangan bo'lsak, bootstrapga patch ishlayotganini bildiramiz
    mainWindow.webContents.once('did-finish-load', () => {
        globalThis.__subgameConfirmBoot?.();
    });
    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}
electron_1.app.whenReady().then(() => {
    const CHROME_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
    electron_1.session.defaultSession.webRequest.onBeforeSendHeaders((details, callback) => {
        details.requestHeaders['User-Agent'] = CHROME_UA;
        callback({ cancel: false, requestHeaders: details.requestHeaders });
    });
    dropStaleUiPatch();
    createWindow();
    void rescueFromTempLaunch();
    electron_1.app.on('activate', () => {
        if (electron_1.BrowserWindow.getAllWindows().length === 0)
            createWindow();
    });
});
electron_1.app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') {
        electron_1.app.quit();
    }
});
// IPC: Window Controls
electron_1.ipcMain.on('window-control', (_, action) => {
    if (!mainWindow)
        return;
    if (action === 'minimize')
        mainWindow.minimize();
    else if (action === 'maximize') {
        if (mainWindow.isMaximized())
            mainWindow.unmaximize();
        else
            mainWindow.maximize();
    }
    else if (action === 'close') {
        mainWindow.close();
    }
});
// IPC: Open External URL in default browser
electron_1.ipcMain.on('open-external', (_, url) => {
    if (url && (url.startsWith('https://') || url.startsWith('http://'))) {
        electron_1.shell.openExternal(url);
    }
});
// IPC: Get Hardware ID
electron_1.ipcMain.handle('get-hwid', () => {
    return (0, hwid_1.getHardwareId)();
});
// IPC: Get Saved Licenses
electron_1.ipcMain.handle('get-licenses', () => {
    const store = (0, license_1.loadLicenseStore)();
    return store.licenses;
});
// IPC: Activate License Key
electron_1.ipcMain.handle('activate-license', (_, { key, gameTitle }) => {
    return (0, license_1.activateLicense)(key, gameTitle);
});
// IPC: Select Game Executable File Dialog
electron_1.ipcMain.handle('select-game-exe', async () => {
    if (!mainWindow)
        return null;
    const result = await electron_1.dialog.showOpenDialog(mainWindow, {
        title: "O'yin ijro faylini (.exe) tanlang",
        properties: ['openFile'],
        filters: [{ name: 'Ijro fayllari (*.exe)', extensions: ['exe'] }],
    });
    if (result.canceled || result.filePaths.length === 0) {
        return null;
    }
    return result.filePaths[0];
});
// IPC: Launch Game with Protection
electron_1.ipcMain.handle('launch-game', async (_, config) => {
    const result = await (0, gameRunner_1.launchGameWithProtection)(config, (status) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('game-status', status);
        }
    });
    return result;
});
// IPC: Install Subtitle Only
electron_1.ipcMain.handle('install-subtitle', async (_, config) => {
    return (0, gameRunner_1.injectSubtitleFile)(config, (status) => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send('game-status', status);
        }
    });
});
// IPC: Get Installed Subtitle Version for a Game
electron_1.ipcMain.handle('get-subtitle-version', (_, gameId) => {
    try {
        if (!gameId)
            return null;
        const versionFile = path_1.default.join(electron_1.app.getPath('userData'), 'subtitles', gameId, 'version.txt');
        if (fs_1.default.existsSync(versionFile)) {
            return fs_1.default.readFileSync(versionFile, 'utf8').trim();
        }
    }
    catch { }
    return null;
});
// IPC: Open Game Folder in Explorer
electron_1.ipcMain.handle('open-game-folder', async (_, exePath) => {
    if (exePath) {
        const dir = fs_1.default.existsSync(exePath) && fs_1.default.statSync(exePath).isFile() ? path_1.default.dirname(exePath) : exePath;
        if (fs_1.default.existsSync(dir)) {
            electron_1.shell.openPath(dir);
            return true;
        }
    }
    return false;
});
// IPC: Get Current App Version (checks for user patch version first)
electron_1.ipcMain.handle('get-app-version', () => {
    try {
        const userVersionFile = path_1.default.join(electron_1.app.getPath('userData'), 'update', 'dist', 'version.json');
        if (fs_1.default.existsSync(userVersionFile)) {
            const data = JSON.parse(fs_1.default.readFileSync(userVersionFile, 'utf8'));
            if (data && data.version) {
                return data.version;
            }
        }
    }
    catch (err) {
        console.warn('Could not read user update version:', err);
    }
    return electron_1.app.getVersion();
});
// IPC: Yangilanish turini tanlash uchun ma'lumot (kichik patch yoki to'liq exe)
electron_1.ipcMain.handle('get-update-info', () => ({
    builtinVersion: electron_1.app.getVersion(),
    blockedPatchVersions: (0, patchVerify_1.readBlockedPatchVersions)(electron_1.app.getPath('userData')),
}));
// IPC: Download Launcher Update with progress (Supports both .zip patch and .exe full update)
electron_1.ipcMain.handle('download-update', async (_, downloadUrl) => {
    try {
        const isZip = downloadUrl.toLowerCase().includes('.zip');
        const tempDir = electron_1.app.getPath('temp');
        const destPath = isZip
            ? path_1.default.join(tempDir, 'SubGame-Launcher-Patch.zip')
            : path_1.default.join(tempDir, 'SubGame-Launcher-Update.exe');
        return await new Promise((resolve) => {
            function doDownload(targetUrl) {
                const client = targetUrl.startsWith('https') ? https_1.default : http_1.default;
                const req = client.get(targetUrl, (res) => {
                    if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                        return doDownload(res.headers.location);
                    }
                    if (res.statusCode !== 200) {
                        return resolve({ success: false, error: `Server xatosi: HTTP ${res.statusCode}` });
                    }
                    const total = parseInt(res.headers['content-length'] || '0', 10);
                    let transferred = 0;
                    const fileStream = fs_1.default.createWriteStream(destPath);
                    res.on('data', (chunk) => {
                        transferred += chunk.length;
                        const percent = total > 0 ? Math.round((transferred / total) * 100) : 0;
                        if (mainWindow && !mainWindow.isDestroyed()) {
                            mainWindow.webContents.send('update-progress', { percent, transferred, total });
                        }
                    });
                    res.pipe(fileStream);
                    fileStream.on('finish', () => {
                        fileStream.close();
                        resolve({ success: true, tempPath: destPath });
                    });
                    fileStream.on('error', (err) => {
                        try {
                            fs_1.default.unlinkSync(destPath);
                        }
                        catch { }
                        resolve({ success: false, error: err.message });
                    });
                });
                req.on('error', (err) => {
                    try {
                        fs_1.default.unlinkSync(destPath);
                    }
                    catch { }
                    resolve({ success: false, error: err.message });
                });
            }
            doDownload(downloadUrl);
        });
    }
    catch (err) {
        return { success: false, error: err?.message || 'Yuklab olishda xatolik yuz berdi' };
    }
});
// IPC: Apply Update & Restart (Instant .zip extraction or PowerShell .exe swap)
electron_1.ipcMain.handle('apply-update', async (_, tempPath) => {
    try {
        if (!fs_1.default.existsSync(tempPath)) {
            return { success: false, error: 'Yangilanish fayli topilmadi.' };
        }
        // 1. Fast Delta Patch Update (.zip)
        if (tempPath.toLowerCase().endsWith('.zip')) {
            const userData = electron_1.app.getPath('userData');
            const updateDir = path_1.default.join(userData, 'update');
            const updateDistDir = path_1.default.join(updateDir, 'dist');
            const stagingDir = path_1.default.join(updateDir, 'staging');
            fs_1.default.rmSync(stagingDir, { recursive: true, force: true });
            fs_1.default.mkdirSync(stagingDir, { recursive: true });
            const { execSync } = require('child_process');
            let extracted = false;
            // Try tar.exe (native on modern Windows)
            try {
                execSync(`tar -xf "${tempPath}" -C "${stagingDir}"`, { stdio: 'ignore' });
                extracted = true;
            }
            catch {
                // Fallback to powershell Expand-Archive
            }
            if (!extracted) {
                const escapedZip = tempPath.replace(/'/g, "''");
                const escapedDest = stagingDir.replace(/'/g, "''");
                const psCmd = `Expand-Archive -LiteralPath '${escapedZip}' -DestinationPath '${escapedDest}' -Force`;
                execSync(`powershell -NoProfile -Command "${psCmd}"`, { stdio: 'ignore' });
            }
            // Faqat imzosi to'g'ri patchni o'rnatamiz; aks holda to'liq yangilanishga o'tiladi
            try {
                const manifest = (0, patchVerify_1.verifyPatchDir)(stagingDir);
                if ((0, patchVerify_1.compareSemver)(manifest.version, electron_1.app.getVersion()) <= 0)
                    throw new Error('patch is not newer');
            }
            catch (verifyErr) {
                console.warn('Patch rejected:', verifyErr?.message);
                fs_1.default.rmSync(stagingDir, { recursive: true, force: true });
                try {
                    fs_1.default.unlinkSync(tempPath);
                }
                catch { }
                return {
                    success: false,
                    fallbackToFull: true,
                    error: "Kichik yangilanishni o'rnatib bo'lmadi. To'liq yangilanish yuklab olinadi.",
                };
            }
            fs_1.default.rmSync(updateDistDir, { recursive: true, force: true });
            fs_1.default.renameSync(stagingDir, updateDistDir);
            try {
                fs_1.default.unlinkSync(path_1.default.join(updateDir, 'boot-pending'));
            }
            catch { }
            try {
                fs_1.default.unlinkSync(tempPath);
            }
            catch { }
            // Fast relaunch directly into the updated UI
            electron_1.app.relaunch();
            setTimeout(() => {
                electron_1.app.quit();
            }, 300);
            return { success: true };
        }
        // 2. Full .exe update (fallback)
        const currentExe = launcherExePath();
        const oldPid = process.pid;
        const escapedTemp = tempPath.replace(/'/g, "''");
        const escapedDest = currentExe.replace(/'/g, "''");
        // Portable exe'da foydalanuvchi ochgan fayl (dest) ilova yopilguncha o'rovchi jarayon tomonidan band
        // turadi. Shuning uchun u bo'shashini kutamiz va nusxa xatosini haqiqatan ushlaymiz (-ErrorAction Stop;
        // 1.4.0 da xato catch ga tushmay, yangilanish faylini o'chirib, eski exe'ni qayta ochardi).
        // Baribir yozib bo'lmasa, yangi exe'ni TEMP dan ochamiz: rescueFromTempLaunch uni ish stoliga saqlaydi.
        const psCommand = [
            `$oldPid = ${oldPid};`,
            `$temp = '${escapedTemp}';`,
            `$dest = '${escapedDest}';`,
            'Wait-Process -Id $oldPid -Timeout 20 -ErrorAction SilentlyContinue;',
            '$deadline = (Get-Date).AddSeconds(30);',
            'while (((Get-Date) -lt $deadline) -and (Get-Process | Where-Object { $_.Path -eq $dest })) { Start-Sleep -Milliseconds 500; }',
            '$ok = $false;',
            'for ($i = 0; ($i -lt 30) -and (-not $ok); $i++) { try { Copy-Item -LiteralPath $temp -Destination $dest -Force -ErrorAction Stop; $ok = $true; } catch { Start-Sleep -Seconds 1; } }',
            'if ($ok) { Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue; Start-Process -FilePath $dest; } else { Start-Process -FilePath $temp; }',
        ].join(' ');
        const child = (0, child_process_1.spawn)('powershell', ['-WindowStyle', 'Hidden', '-NoProfile', '-Command', psCommand], {
            detached: true,
            stdio: 'ignore',
            windowsHide: true,
        });
        child.unref();
        setTimeout(() => {
            electron_1.app.quit();
        }, 200);
        return { success: true };
    }
    catch (err) {
        return { success: false, error: err?.message || 'Yangilanishni qo‘llashda xatolik' };
    }
});
