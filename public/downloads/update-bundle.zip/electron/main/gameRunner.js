"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isProcessRunning = isProcessRunning;
exports.spawnDetachedCleanupWatcher = spawnDetachedCleanupWatcher;
exports.safeCopyFileSync = safeCopyFileSync;
exports.safeWriteFileSync = safeWriteFileSync;
exports.findSubtitleSource = findSubtitleSource;
exports.resolveTargetDir = resolveTargetDir;
exports.formatDownloadUrl = formatDownloadUrl;
exports.downloadSubtitleFile = downloadSubtitleFile;
exports.injectSubtitleFile = injectSubtitleFile;
exports.launchGameWithProtection = launchGameWithProtection;
const child_process_1 = require("child_process");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const https_1 = __importDefault(require("https"));
const http_1 = __importDefault(require("http"));
const electron_1 = require("electron");
const license_1 = require("./license");
const crypto_1 = require("./crypto");
const rangePatch_1 = require("./rangePatch");
const activeSessions = new Map();
/**
 * Foydalanuvchiga ko'rsatiladigan xato matnidan fayl yo'llari va nomlarini olib tashlaydi
 * (qaysi fayl yuklanayotgani/qo'yilayotgani launcherda ko'rinmasligi kerak).
 */
function hideFileDetails(err) {
    const msg = String(err?.message || err || '');
    return msg
        .replace(/[A-Za-z]:[\\/][^\s'"`,;)]+/g, '')
        .replace(/'[^']*[\\/][^']*'/g, '')
        .replace(/\b[\w.-]+\.(psarc|pak|enc|sds|pc|rpf|assets|swf|patch|subgame_\w+)\b/gi, '')
        .replace(/\s{2,}/g, ' ')
        .trim();
}
/**
 * Windows jarayonini tekshirish (tasklist orqali)
 */
function isProcessRunning(pattern) {
    if (!pattern)
        return false;
    try {
        const output = (0, child_process_1.execFileSync)('tasklist', ['/nh', '/fi', `imagename eq ${pattern}*`], {
            encoding: 'utf8',
            windowsHide: true,
            stdio: ['ignore', 'pipe', 'ignore'],
        });
        return output.toLowerCase().includes(pattern.toLowerCase());
    }
    catch {
        return false;
    }
}
/**
 * Mustaqil fon jarayoni (Detached Watcher)
 * Launcher yopilsa ham, o'yin jarayoni tugashi bilan subtitr faylini xavfsiz o'chiradi yoki zaxiradan tiklaydi
 */
function spawnDetachedCleanupWatcher(pattern, filesOrDest, legacyBackupPath) {
    try {
        const fileEntries = Array.isArray(filesOrDest)
            ? filesOrDest.map((f) => ({ dest: f.destFilePath, bak: f.backupFilePath || '', kind: f.kind || 'file' }))
            : [{ dest: filesOrDest, bak: legacyBackupPath || '', kind: 'file' }];
        if (fileEntries.length === 0)
            return;
        const escapedPattern = pattern.replace(/'/g, "''");
        const fileArrayScript = fileEntries
            .map((f) => `@{ dest = '${f.dest.replace(/'/g, "''")}'; bak = '${f.bak.replace(/'/g, "''")}'; kind = '${f.kind}' }`)
            .join(', ');
        const psCommand = `
      $pattern = '${escapedPattern}';
      $files = @(${fileArrayScript});
      $t = 0;
      while (!(Get-Process -Name $pattern* -ErrorAction SilentlyContinue) -and $t -lt 30) {
        Start-Sleep -Seconds 1;
        $t++;
      };
      while (Get-Process -Name $pattern* -ErrorAction SilentlyContinue) {
        Start-Sleep -Seconds 2;
      };
      Start-Sleep -Seconds 1;
      foreach ($f in $files) {
        for ($i = 0; $i -lt 15; $i++) {
          try {
            if ($f.kind -eq 'range') {
              if ($f.bak -and (Test-Path -LiteralPath $f.bak)) {
                $dest = $f.dest; $bak = $f.bak;
                ${rangePatch_1.POWERSHELL_RANGE_RESTORE}
              }
            } elseif ($f.bak -and (Test-Path -LiteralPath $f.bak)) {
              Copy-Item -LiteralPath $f.bak -Destination $f.dest -Force;
              Remove-Item -LiteralPath $f.bak -Force;
            } elseif (Test-Path -LiteralPath $f.dest) {
              Remove-Item -LiteralPath $f.dest -Force;
            }
            break;
          } catch {
            Start-Sleep -Seconds 1;
          }
        }
      }
    `.replace(/\\s+/g, ' ').trim();
        const watcher = (0, child_process_1.spawn)('powershell', ['-WindowStyle', 'Hidden', '-NoProfile', '-Command', psCommand], {
            detached: true,
            stdio: 'ignore',
            windowsHide: true,
        });
        watcher.unref();
    }
    catch (err) {
        console.warn('Detached watcher start warning:', err);
    }
}
/**
 * Xavfsiz nusxalash (Program Files papkasida EPERM xatosi bo'lsa, UAC orqali ruxsat oladi)
 */
function safeCopyFileSync(source, destination) {
    try {
        if (fs_1.default.existsSync(destination)) {
            try {
                fs_1.default.chmodSync(destination, 0o666);
            }
            catch {
                // ignore
            }
        }
        fs_1.default.copyFileSync(source, destination);
    }
    catch (err) {
        if (err.code === 'EPERM' || err.code === 'EACCES') {
            try {
                const psCommand = `powershell -NoProfile -Command "Start-Process powershell -Verb RunAs -Wait -ArgumentList '-NoProfile -Command Copy-Item -LiteralPath \\'${source}\\' -Destination \\'${destination}\\' -Force'"`;
                (0, child_process_1.execSync)(psCommand, { stdio: 'ignore' });
                if (fs_1.default.existsSync(destination)) {
                    return;
                }
            }
            catch (elevateErr) {
                console.error('PowerShell elevate error:', elevateErr);
            }
            throw new Error(`Faylni yozishga ruxsat berilmadi (EPERM). O'yin "Program Files" papkasida joylashganligi sababli, iltimos SubGame Launcherni "Administrator sifatida ishga tushirish" (Run as administrator) orqali oching.`);
        }
        throw err;
    }
}
/**
 * Xavfsiz fayl yozish (Buffer dan to'g'ridan-to'g'ri yozish)
 */
function safeWriteFileSync(destination, data) {
    try {
        if (fs_1.default.existsSync(destination)) {
            try {
                fs_1.default.chmodSync(destination, 0o666);
            }
            catch {
                // ignore
            }
        }
        fs_1.default.writeFileSync(destination, data);
    }
    catch (err) {
        if (err.code === 'EPERM' || err.code === 'EACCES') {
            const tempPath = path_1.default.join(electron_1.app.getPath('temp'), `subgame_${Date.now()}_${path_1.default.basename(destination)}`);
            fs_1.default.writeFileSync(tempPath, data);
            safeCopyFileSync(tempPath, destination);
            try {
                fs_1.default.unlinkSync(tempPath);
            }
            catch { }
            return;
        }
        throw err;
    }
}
/**
 * Subtitr manba faylini qidirish (shifrlangan .enc yoki asl fayl)
 */
function findSubtitleSource(gameId, fileName) {
    const encName = `${fileName}.enc`;
    const resPath = process.resourcesPath;
    // Avval shifrlangan .enc faylni qidiramiz, keyin asl faylni
    for (const f of [encName, fileName]) {
        const candidatePaths = [
            path_1.default.join(electron_1.app.getPath('userData'), 'subtitles', gameId, f),
            ...(resPath ? [
                path_1.default.join(resPath, 'subtitles', gameId, f),
                path_1.default.join(resPath, 'public', 'subtitles', gameId, f),
                path_1.default.join(resPath, 'app.asar.unpacked', 'dist', 'subtitles', gameId, f),
                path_1.default.join(resPath, 'app.asar.unpacked', 'public', 'subtitles', gameId, f),
            ] : []),
            path_1.default.join(electron_1.app.getAppPath(), 'dist', 'subtitles', gameId, f),
            path_1.default.join(electron_1.app.getAppPath(), 'public', 'subtitles', gameId, f),
            path_1.default.join(__dirname, '../../dist/subtitles', gameId, f),
            path_1.default.join(__dirname, '../../public/subtitles', gameId, f),
            path_1.default.join(__dirname, '../subtitles', gameId, f),
        ];
        for (const p of candidatePaths) {
            try {
                if (fs_1.default.existsSync(p)) {
                    let isEncrypted = f.endsWith('.enc');
                    if (!isEncrypted) {
                        try {
                            const testBuf = fs_1.default.readFileSync(p);
                            (0, crypto_1.decryptData)(testBuf);
                            isEncrypted = true;
                        }
                        catch {
                            isEncrypted = false;
                        }
                    }
                    return { path: p, isEncrypted };
                }
            }
            catch {
                // ignore
            }
        }
    }
    return null;
}
/**
 * O'yin papkasi ichidagi subtitr joylashadigan maqsad papkani aniqlash (TRTEXT yoki boshqa)
 */
function resolveTargetDir(gameDir, targetRelativeDir) {
    if (targetRelativeDir) {
        const candidates = [
            path_1.default.join(gameDir, targetRelativeDir),
            path_1.default.resolve(gameDir, '../../..', targetRelativeDir),
            path_1.default.resolve(gameDir, '../..', targetRelativeDir),
            path_1.default.resolve(gameDir, '..', targetRelativeDir),
        ];
        for (const c of candidates) {
            if (fs_1.default.existsSync(c)) {
                return c;
            }
        }
    }
    // A Plague Tale seriyasida matnlar TRTEXT papkasida joylashgan
    if (fs_1.default.existsSync(path_1.default.join(gameDir, 'TRTEXT'))) {
        return path_1.default.join(gameDir, 'TRTEXT');
    }
    if (targetRelativeDir) {
        const customDir = path_1.default.join(gameDir, targetRelativeDir);
        if (!fs_1.default.existsSync(customDir)) {
            try {
                fs_1.default.mkdirSync(customDir, { recursive: true });
            }
            catch { }
        }
        return customDir;
    }
    return gameDir;
}
/**
 * Google Drive yoki boshqa havolalarni to'g'ridan-to'g'ri yuklab olish formatiga keltirish
 */
function formatDownloadUrl(rawUrl) {
    if (!rawUrl)
        return '';
    const gDriveMatch = rawUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
    if (gDriveMatch && gDriveMatch[1]) {
        return `https://drive.usercontent.google.com/download?id=${gDriveMatch[1]}&export=download&confirm=t`;
    }
    const gDriveIdMatch = rawUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
    if (gDriveIdMatch && gDriveIdMatch[1] && rawUrl.includes('drive.google.com')) {
        return `https://drive.usercontent.google.com/download?id=${gDriveIdMatch[1]}&export=download&confirm=t`;
    }
    return rawUrl;
}
/**
 * Subtitr faylini serverdan 0-100% progress bilan yuklab olish
 */
async function downloadSubtitleFile(rawUrl, destPath, onStatusUpdate) {
    const url = formatDownloadUrl(rawUrl);
    const dir = path_1.default.dirname(destPath);
    if (!fs_1.default.existsSync(dir)) {
        fs_1.default.mkdirSync(dir, { recursive: true });
    }
    onStatusUpdate?.({
        type: 'download-progress',
        percent: 0,
        transferredMb: '0.0',
        totalMb: '...',
        message: 'Serverga ulanmoqda...'
    });
    return new Promise((resolve, reject) => {
        const client = url.startsWith('https') ? https_1.default : http_1.default;
        const req = client.get(url, (res) => {
            // 301, 302, 303, 307 redirectlarni xavfsiz boshqarish
            if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                let redirectUrl = res.headers.location;
                if (!redirectUrl.startsWith('http')) {
                    const parsedOrigin = new URL(url).origin;
                    redirectUrl = new URL(redirectUrl, parsedOrigin).href;
                }
                return downloadSubtitleFile(redirectUrl, destPath, onStatusUpdate).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) {
                return reject(new Error(`Server javobi: HTTP ${res.statusCode}`));
            }
            const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
            let downloadedBytes = 0;
            let lastReportTime = 0;
            const fileStream = fs_1.default.createWriteStream(destPath);
            res.on('data', (chunk) => {
                downloadedBytes += chunk.length;
                const now = Date.now();
                // UI silliq ishlashi uchun xabarlarni ~80ms oraliqda jo'natamiz
                if (now - lastReportTime > 80 || (totalBytes > 0 && downloadedBytes >= totalBytes)) {
                    lastReportTime = now;
                    if (totalBytes > 0) {
                        const percent = Math.min(100, Math.round((downloadedBytes / totalBytes) * 100));
                        const dlMB = (downloadedBytes / (1024 * 1024)).toFixed(1);
                        const totMB = (totalBytes / (1024 * 1024)).toFixed(1);
                        onStatusUpdate?.({
                            type: 'download-progress',
                            percent,
                            transferredMb: dlMB,
                            totalMb: totMB,
                            message: `Subtitr yuklanmoqda: ${percent}% (${dlMB} MB / ${totMB} MB)`
                        });
                    }
                    else {
                        const dlMB = (downloadedBytes / (1024 * 1024)).toFixed(1);
                        onStatusUpdate?.({
                            type: 'download-progress',
                            percent: -1,
                            transferredMb: dlMB,
                            totalMb: '?',
                            message: `Subtitr yuklanmoqda: ${dlMB} MB`
                        });
                    }
                }
            });
            res.pipe(fileStream);
            fileStream.on('finish', () => {
                fileStream.close();
                const dlMB = (downloadedBytes / (1024 * 1024)).toFixed(1);
                onStatusUpdate?.({
                    type: 'download-progress',
                    percent: 100,
                    transferredMb: dlMB,
                    totalMb: dlMB,
                    message: 'Subtitr to‘liq yuklab olindi (100%)'
                });
                resolve();
            });
            fileStream.on('error', (err) => {
                try {
                    fs_1.default.unlinkSync(destPath);
                }
                catch { }
                reject(err);
            });
        });
        req.on('error', (err) => {
            try {
                fs_1.default.unlinkSync(destPath);
            }
            catch { }
            reject(err);
        });
    });
}
/**
 * Subtitr faylini o'yin papkasiga xavfsiz dekodlab joylash
 * Bir yoki bir nechta subtitr fayllarini qo'llab-quvvatlaydi (masalan, stringtable_en.sds,stringtable_ru.sds)
 */
async function injectSubtitleFile(config, onStatusUpdate) {
    try {
        if (config.skipSubtitleInjection || !config.targetSubtitleFileName || config.targetSubtitleFileName === 'none') {
            return {
                success: true,
                message: "O‘yin lokalizatsiyasi tayyor.",
            };
        }
        if (!fs_1.default.existsSync(config.gameExePath)) {
            return {
                success: false,
                message: `O'yin ijro fayli (.exe) topilmadi: ${config.gameExePath}`,
            };
        }
        const gameDir = path_1.default.dirname(config.gameExePath);
        const destDir = resolveTargetDir(gameDir, config.targetRelativeDir);
        if (!fs_1.default.existsSync(destDir)) {
            fs_1.default.mkdirSync(destDir, { recursive: true });
        }
        // Avvalgi xatolikdan qolgan noto'g'ri nomli faylni tozalash
        try {
            const junkCorrupted = path_1.default.join(destDir, 'stringtable_en.sds,stringtable_ru.sds');
            if (fs_1.default.existsSync(junkCorrupted)) {
                fs_1.default.unlinkSync(junkCorrupted);
            }
        }
        catch { }
        const fileNames = config.targetSubtitleFileName
            .split(/[,;|]/)
            .map((s) => s.trim())
            .filter(Boolean);
        // Mafia: Definitive Edition uchun agar faqat stringtable_en.sds ko'rsatilgan bo'lsa ham,
        // o'yin papkasida stringtable_ru.sds bo'lsa, ikkala til foydalanuvchilariga ham ishlashi uchun uni ham qo'shamiz
        if (config.gameId === 'mafia-definitive-edition' ||
            config.gameExePath.toLowerCase().includes('mafiadefinitiveedition')) {
            if (!fileNames.includes('stringtable_ru.sds') && fs_1.default.existsSync(path_1.default.join(destDir, 'stringtable_ru.sds'))) {
                fileNames.push('stringtable_ru.sds');
            }
        }
        const userSubDir = path_1.default.join(electron_1.app.getPath('userData'), 'subtitles', config.gameId);
        const versionFilePath = path_1.default.join(userSubDir, 'version.txt');
        // Subtitr versiyasini tekshirish (Subtitle Version Auto-Updater)
        let needsVersionUpdate = false;
        if (config.subtitleVersion && config.subtitleDownloadUrl && config.subtitleDownloadUrl.startsWith('http')) {
            if (fs_1.default.existsSync(versionFilePath)) {
                try {
                    const installedVer = fs_1.default.readFileSync(versionFilePath, 'utf8').trim();
                    if (installedVer && installedVer !== config.subtitleVersion.trim()) {
                        console.info(`[Subtitle Updater] New version available for ${config.gameId}: ${config.subtitleVersion} (current: ${installedVer}). Triggering re-download.`);
                        needsVersionUpdate = true;
                    }
                }
                catch { }
            }
            else {
                for (const f of fileNames) {
                    const testFile = path_1.default.join(userSubDir, f);
                    const testEnc = path_1.default.join(userSubDir, `${f}.enc`);
                    if (fs_1.default.existsSync(testFile) || fs_1.default.existsSync(testEnc)) {
                        needsVersionUpdate = true;
                        break;
                    }
                }
            }
            if (needsVersionUpdate) {
                for (const f of fileNames) {
                    try {
                        const oldFile = path_1.default.join(userSubDir, f);
                        const oldEnc = path_1.default.join(userSubDir, `${f}.enc`);
                        if (fs_1.default.existsSync(oldFile))
                            fs_1.default.unlinkSync(oldFile);
                        if (fs_1.default.existsSync(oldEnc))
                            fs_1.default.unlinkSync(oldEnc);
                    }
                    catch { }
                }
            }
        }
        // Agar lokal papkalarda barcha fayllar topilmasa va server URL berilgan bo'lsa, yuklab olamiz
        let allFound = !needsVersionUpdate && fileNames.every((f) => findSubtitleSource(config.gameId, f) !== null);
        if (!allFound && config.subtitleDownloadUrl && config.subtitleDownloadUrl.startsWith('http')) {
            try {
                if (!fs_1.default.existsSync(userSubDir)) {
                    fs_1.default.mkdirSync(userSubDir, { recursive: true });
                }
                const tempDownloadPath = path_1.default.join(userSubDir, `temp_download_${Date.now()}`);
                onStatusUpdate?.("Subtitr serverdan yuklanmoqda...");
                await downloadSubtitleFile(config.subtitleDownloadUrl, tempDownloadPath, onStatusUpdate);
                if (fs_1.default.existsSync(tempDownloadPath)) {
                    // Fayl turini tekshirish: Zip arxivmi yoki to'g'ridan-to'g'ri faylmi?
                    let isZipFile = false;
                    try {
                        const fd = fs_1.default.openSync(tempDownloadPath, 'r');
                        const magicBuf = Buffer.alloc(4);
                        fs_1.default.readSync(fd, magicBuf, 0, 4, 0);
                        fs_1.default.closeSync(fd);
                        // PK\x03\x04 (ZIP signature)
                        if (magicBuf[0] === 0x50 && magicBuf[1] === 0x4b && magicBuf[2] === 0x03 && magicBuf[3] === 0x04) {
                            isZipFile = true;
                        }
                    }
                    catch { }
                    if (isZipFile) {
                        try {
                            (0, child_process_1.execSync)(`powershell -NoProfile -Command "Expand-Archive -LiteralPath '${tempDownloadPath.replace(/'/g, "''")}' -DestinationPath '${userSubDir.replace(/'/g, "''")}' -Force"`, { windowsHide: true });
                        }
                        catch (unzipErr) {
                            console.warn('Zip faylni ochishda xatolik:', unzipErr);
                        }
                        try {
                            fs_1.default.unlinkSync(tempDownloadPath);
                        }
                        catch { }
                    }
                    else {
                        // To'g'ridan-to'g'ri (zipsiz) subtitr fayli (masalan, .sds)
                        const primaryName = fileNames[0] || 'stringtable_en.sds';
                        const primaryFile = path_1.default.join(userSubDir, primaryName);
                        try {
                            if (fs_1.default.existsSync(primaryFile))
                                fs_1.default.unlinkSync(primaryFile);
                        }
                        catch { }
                        fs_1.default.renameSync(tempDownloadPath, primaryFile);
                        // Agar o'yin uchun qo'shimcha nomlar kerak bo'lsa (masalan, stringtable_ru.sds)
                        for (let i = 1; i < fileNames.length; i++) {
                            const secondaryFile = path_1.default.join(userSubDir, fileNames[i]);
                            try {
                                safeCopyFileSync(primaryFile, secondaryFile);
                            }
                            catch { }
                        }
                    }
                    if (config.subtitleVersion) {
                        try {
                            fs_1.default.writeFileSync(versionFilePath, config.subtitleVersion.trim(), 'utf8');
                        }
                        catch { }
                    }
                }
            }
            catch (dlErr) {
                console.warn('Subtitrni yuklab olishda ogohlantirish:', dlErr);
            }
        }
        const injectedList = [];
        for (const targetFileName of fileNames) {
            const destFilePath = path_1.default.join(destDir, targetFileName);
            const backupFilePath = path_1.default.join(destDir, `${targetFileName}.subgame_bak`);
            let source = findSubtitleSource(config.gameId, targetFileName);
            // Agar aynan shu nomdagi manba topilmasa, lekin boshqa fayl yuklangan bo'lsa (masalan, EN -> RU nusxalash)
            if (!source) {
                for (const otherF of fileNames) {
                    const altSource = findSubtitleSource(config.gameId, otherF);
                    if (altSource) {
                        source = altSource;
                        break;
                    }
                }
            }
            // Agar yuqoridagi umumiy yuklashdan keyin ham topilmagan bo'lsa va yakka fayl URL bo'lsa
            if (!source && config.subtitleDownloadUrl && config.subtitleDownloadUrl.startsWith('http') && fileNames.length === 1) {
                try {
                    if (!fs_1.default.existsSync(userSubDir)) {
                        fs_1.default.mkdirSync(userSubDir, { recursive: true });
                    }
                    const downloadedFilePath = path_1.default.join(userSubDir, targetFileName);
                    await downloadSubtitleFile(config.subtitleDownloadUrl, downloadedFilePath, onStatusUpdate);
                    if (fs_1.default.existsSync(downloadedFilePath)) {
                        let isEncrypted = false;
                        try {
                            const testBuf = fs_1.default.readFileSync(downloadedFilePath);
                            (0, crypto_1.decryptData)(testBuf);
                            isEncrypted = true;
                        }
                        catch {
                            isEncrypted = false;
                        }
                        source = { path: downloadedFilePath, isEncrypted };
                    }
                }
                catch (dlErr) {
                    console.warn('Subtitrni yuklab olishda ogohlantirish:', dlErr);
                }
            }
            if (!source) {
                return {
                    success: false,
                    message: "O'zbekcha paket topilmadi. Internet aloqasini tekshirib, qaytadan urinib ko'ring.",
                };
            }
            onStatusUpdate?.("O'zbekcha paket o'yinga xavfsiz ulanmoqda...");
            // Bayt-oraliq patchi (SGPATCH1): katta arxivlarni butunlay nusxalamay, joyida patchlaymiz
            let sourceBuffer = null;
            try {
                const rawBuf = fs_1.default.readFileSync(source.path);
                try {
                    sourceBuffer = (0, crypto_1.decryptData)(rawBuf);
                }
                catch {
                    sourceBuffer = source.isEncrypted ? null : rawBuf;
                }
            }
            catch { }
            if ((0, rangePatch_1.isRangePatch)(sourceBuffer)) {
                if (!fs_1.default.existsSync(destFilePath)) {
                    return {
                        success: false,
                        message: "O'yin fayllari to'liq emas. O'yin papkasini to'g'ri tanlaganingizni tekshiring.",
                    };
                }
                const rangeBackupPath = `${destFilePath}.subgame_rangebak`;
                try {
                    (0, rangePatch_1.applyRangePatch)(destFilePath, sourceBuffer, rangeBackupPath);
                }
                catch (patchErr) {
                    return {
                        success: false,
                        message: `O'zbekcha paketni ulab bo'lmadi: ${hideFileDetails(patchErr)}`,
                    };
                }
                injectedList.push({ destFilePath, backupFilePath: rangeBackupPath, kind: 'range' });
                continue;
            }
            // Agar o'yin papkasida asl fayl mavjud bo'lsa va hali zaxiralanmagan bo'lsa, zaxiraga olamiz
            if (fs_1.default.existsSync(destFilePath) && !fs_1.default.existsSync(backupFilePath)) {
                try {
                    safeCopyFileSync(destFilePath, backupFilePath);
                }
                catch (err) {
                    console.warn(`Original faylni zaxiralashda ogohlantirish (${targetFileName}):`, err);
                }
            }
            // AES-256 bilan shifrlangan bo'lsa dekodlaymiz
            let decryptedBuffer = null;
            if (source.isEncrypted) {
                try {
                    const encryptedBuffer = fs_1.default.readFileSync(source.path);
                    decryptedBuffer = (0, crypto_1.decryptData)(encryptedBuffer);
                }
                catch (decryptErr) {
                    console.warn(`Dekodlashda ogohlantirish (${targetFileName}):`, decryptErr);
                }
            }
            else {
                try {
                    const testBuffer = fs_1.default.readFileSync(source.path);
                    decryptedBuffer = (0, crypto_1.decryptData)(testBuffer);
                }
                catch {
                    decryptedBuffer = null;
                }
            }
            if (decryptedBuffer) {
                safeWriteFileSync(destFilePath, decryptedBuffer);
            }
            else {
                safeCopyFileSync(source.path, destFilePath);
            }
            injectedList.push({ destFilePath, backupFilePath });
        }
        return {
            success: true,
            message: `O‘zbekcha subtitr paketi o‘yinga muvaffaqiyatli ulandi!`,
            targetPath: injectedList[0]?.destFilePath,
            injectedFiles: injectedList,
        };
    }
    catch (error) {
        return {
            success: false,
            message: `Subtitrni joylashda xatolik: ${hideFileDetails(error)}`,
        };
    }
}
/**
 * O'yinni o'zbekcha subtitrlar bilan ishga tushirish (A-Variant DRM)
 */
/**
 * O'yin papkasiga qo'yilgan fayllarni asl holiga qaytaradi (zaxiradan tiklaydi yoki o'chiradi).
 */
async function restoreInjectedFiles(injectedList, gameExePath) {
    for (const item of injectedList) {
        if (!item.destFilePath || item.destFilePath === gameExePath)
            continue;
        for (let attempt = 0; attempt < 10; attempt++) {
            try {
                if (item.kind === 'range') {
                    // Arxivni hech qachon o'chirmaymiz: faqat asl baytlarni qaytaramiz
                    if (item.backupFilePath)
                        (0, rangePatch_1.restoreRangePatch)(item.destFilePath, item.backupFilePath);
                    break;
                }
                if (item.backupFilePath && fs_1.default.existsSync(item.backupFilePath)) {
                    safeCopyFileSync(item.backupFilePath, item.destFilePath);
                    try {
                        fs_1.default.unlinkSync(item.backupFilePath);
                    }
                    catch { }
                    break;
                }
                else if (fs_1.default.existsSync(item.destFilePath)) {
                    fs_1.default.unlinkSync(item.destFilePath);
                    break;
                }
            }
            catch {
                await new Promise((r) => setTimeout(r, 1000));
            }
        }
    }
}
/**
 * O'yin exe'sini oddiy jarayon sifatida ishga tushiradi.
 * Windows jarayonni yaratgach resolve bo'ladi, rad etsa spawn xatosi bilan reject bo'ladi
 * (xato 'error' hodisasida keladi, uni ushlamasak main process qulaydi).
 */
function spawnGameProcess(exePath, cwd) {
    return new Promise((resolve, reject) => {
        const child = (0, child_process_1.spawn)(exePath, [], { cwd, detached: true, stdio: 'ignore' });
        child.once('spawn', () => {
            child.unref();
            resolve(child);
        });
        child.once('error', reject);
    });
}
/**
 * Exe "Administrator sifatida ishga tushirish" deb belgilangan bo'lsa (Compatibility sozlamasi
 * yoki manifest), oddiy spawn Windows 740 xatosi bilan rad etiladi — Node buni EACCES deb beradi.
 * Bunday holda UAC oynasi orqali ishga tushiramiz. Foydalanuvchi rad etsa, reject bo'ladi.
 */
function startGameElevated(exePath, cwd) {
    const quote = (s) => `'${s.replace(/'/g, "''")}'`;
    const command = `Start-Process -FilePath ${quote(exePath)} -WorkingDirectory ${quote(cwd)} -Verb RunAs`;
    return new Promise((resolve, reject) => {
        (0, child_process_1.execFile)('powershell', ['-NoProfile', '-NonInteractive', '-Command', command], { windowsHide: true }, (err) => err ? reject(err) : resolve());
    });
}
function needsElevation(err) {
    return err?.code === 'EACCES' || err?.errno === 740 || err?.errno === -4092;
}
async function launchGameWithProtection(config, onStatusUpdate) {
    try {
        onStatusUpdate('Litsenziya tekshirilmoqda...');
        // 1. Check license
        const hasLocalLicense = (0, license_1.isGameActivated)(config.gameId);
        if (!config.isAuthorized && !hasLocalLicense) {
            return {
                success: false,
                message: "Ushbu o'yin uchun litsenziya faollashtirilmagan! Iltimos, hisobingizga kiring yoki litsenziya kalitini kiriting.",
            };
        }
        // 2. Validate Game Executable exists
        if (!fs_1.default.existsSync(config.gameExePath)) {
            return {
                success: false,
                message: `O'yin ijro fayli (.exe) topilmadi: ${config.gameExePath}`,
            };
        }
        const shouldInject = !config.skipSubtitleInjection && !!config.targetSubtitleFileName && config.targetSubtitleFileName !== 'none';
        const gameDir = path_1.default.dirname(config.gameExePath);
        let injectedList = [];
        // 3. Inject subtitle into target directory if needed (e.g. TRTEXT/tt01.pc)
        if (shouldInject) {
            const injectRes = await injectSubtitleFile(config, onStatusUpdate);
            if (!injectRes.success) {
                return injectRes;
            }
            injectedList = injectRes.injectedFiles || [];
        }
        else {
            onStatusUpdate("O'yin ishga tushirishga tayyorlanmoqda...");
        }
        onStatusUpdate("O'yin ishga tushirilmoqda...");
        // Extract process pattern (e.g. Stray from Stray.exe or Stray-Win64-Shipping.exe)
        const rawExeName = path_1.default.basename(config.gameExePath, path_1.default.extname(config.gameExePath));
        let processPattern = rawExeName.replace(/[-_](Win64|Win32|Shipping|x64|x86)+.*$/i, '');
        if (processPattern.length < 3) {
            processPattern = rawExeName;
        }
        // 4. Launch Game process
        let gameProcess = null;
        try {
            gameProcess = await spawnGameProcess(config.gameExePath, gameDir);
        }
        catch (spawnErr) {
            let started = false;
            if (needsElevation(spawnErr)) {
                onStatusUpdate("O'yin administrator ruxsatini so'rayapti...");
                try {
                    await startGameElevated(config.gameExePath, gameDir);
                    started = true;
                }
                catch { }
            }
            if (!started) {
                if (shouldInject && injectedList.length > 0) {
                    await restoreInjectedFiles(injectedList, config.gameExePath);
                }
                return {
                    success: false,
                    message: needsElevation(spawnErr)
                        ? "O'yin administrator ruxsatisiz ishga tushmaydi. So'rov oynasida \"Ha\" ni bosing yoki o'yin exe faylining Compatibility sozlamasidan \"Run this program as an administrator\" belgisini olib tashlang."
                        : `O'yinni ishga tushirib bo'lmadi: ${hideFileDetails(spawnErr)}`,
                };
            }
        }
        activeSessions.set(config.gameId, {
            process: gameProcess,
            gameId: config.gameId,
        });
        // Windows mustaqil tozalovchi jarayonini ishga tushiramiz (Launcher yopilsa ham fonda ishlaydi)
        if (shouldInject && injectedList.length > 0) {
            spawnDetachedCleanupWatcher(processPattern, injectedList);
        }
        onStatusUpdate("O'yin faol va o'zbekcha subtitrlar ulandi. Maroqli hordiq!");
        // 5. A-Variant DRM: O'yin ichki monitori (Launcher ochiq turganda real vaqtda kuzatadi va tozalaydi)
        let checkCount = 0;
        let gameHasStarted = false;
        const monitorInterval = setInterval(async () => {
            checkCount++;
            const isRunning = isProcessRunning(processPattern);
            if (isRunning) {
                gameHasStarted = true;
            }
            // O'yin ishga tushib keyin yopilsa, yoki 30 soniya ichida umuman boshlanmasa
            if ((gameHasStarted && !isRunning) || (!gameHasStarted && checkCount > 15)) {
                clearInterval(monitorInterval);
                activeSessions.delete(config.gameId);
                onStatusUpdate("O'yin yakunlandi. Subtitrlar himoyalanmoqda...");
                if (shouldInject && injectedList.length > 0) {
                    await restoreInjectedFiles(injectedList, config.gameExePath);
                }
                onStatusUpdate('Tayyor');
            }
        }, 2000);
        return {
            success: true,
            message: "O'yin va o'zbekcha subtitrlar muvaffaqiyatli ishga tushirildi!",
        };
    }
    catch (error) {
        return {
            success: false,
            message: `Ishga tushirishda xatolik: ${hideFileDetails(error)}`,
        };
    }
}
