"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadLicenseStore = loadLicenseStore;
exports.saveLicenseStore = saveLicenseStore;
exports.validateKeyFormat = validateKeyFormat;
exports.activateLicense = activateLicense;
exports.isGameActivated = isGameActivated;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const electron_1 = require("electron");
const crypto_1 = __importDefault(require("crypto"));
const hwid_1 = require("./hwid");
const MASTER_SIGNING_SALT = 'SUBGAME_2026_PRODUCTION_SECRET_KEY';
function getStoragePath() {
    const base = electron_1.app?.getPath('userData') || path_1.default.resolve(process.cwd(), '.launcher-data');
    if (!fs_1.default.existsSync(base)) {
        fs_1.default.mkdirSync(base, { recursive: true });
    }
    return path_1.default.join(base, 'licenses.v1.dat');
}
function computeSignature(licenses, hwid) {
    const content = JSON.stringify(licenses) + '::' + hwid + '::' + MASTER_SIGNING_SALT;
    return crypto_1.default.createHash('sha256').update(content).digest('hex');
}
function loadLicenseStore() {
    const filePath = getStoragePath();
    const currentHwid = (0, hwid_1.getHardwareId)().hwid;
    if (!fs_1.default.existsSync(filePath)) {
        return {
            version: 1,
            hwid: currentHwid,
            signature: computeSignature({}, currentHwid),
            licenses: {},
        };
    }
    try {
        const raw = fs_1.default.readFileSync(filePath, 'utf-8');
        const parsed = JSON.parse(raw);
        // Anti-tamper check: If someone copied this licenses file from another PC:
        if (parsed.hwid !== currentHwid) {
            console.warn('Litsenziya fayli boshqa kompyuterdan ko\'chirilgan! Bloklandi.');
            return {
                version: 1,
                hwid: currentHwid,
                signature: computeSignature({}, currentHwid),
                licenses: {},
            };
        }
        // Verify cryptographic signature to ensure file wasn't edited manually with Notepad
        const expectedSig = computeSignature(parsed.licenses, currentHwid);
        if (parsed.signature !== expectedSig) {
            console.warn('Litsenziya fayli tahrirlangan (tampered)! Bloklandi.');
            return {
                version: 1,
                hwid: currentHwid,
                signature: computeSignature({}, currentHwid),
                licenses: {},
            };
        }
        return parsed;
    }
    catch (e) {
        console.error('Litsenziya faylini o\'qishda xatolik:', e);
        return {
            version: 1,
            hwid: currentHwid,
            signature: computeSignature({}, currentHwid),
            licenses: {},
        };
    }
}
function saveLicenseStore(store) {
    const filePath = getStoragePath();
    store.hwid = (0, hwid_1.getHardwareId)().hwid;
    store.signature = computeSignature(store.licenses, store.hwid);
    fs_1.default.writeFileSync(filePath, JSON.stringify(store, null, 2), 'utf-8');
}
/**
 * Validates a license key format and checks eligibility
 */
function validateKeyFormat(key) {
    const cleanKey = key.trim().toUpperCase();
    // Standard format: SUB-{GAME_PREFIX}-{4 CHARS}-{4 CHARS}
    // e.g. SUB-INNO-7842-AB12, SUB-REQU-9912-XX44, SUB-OUTW-1234-ABCD, SUB-DEMO-0001-TEST, SUB-RDR1-XXXX-XXXX
    const regex = /^SUB-(INNO|REQU|OUTW|DEMO|GAME|RDR1|STRA|RE2R|RLPA|MAFI)-[A-Z0-9]{4}-[A-Z0-9]{4}$/;
    if (!regex.test(cleanKey)) {
        return { valid: false, error: "Litsenziya kaliti formati noto'g'ri. Namuna: SUB-INNO-8492-XK91" };
    }
    const parts = cleanKey.split('-');
    const prefix = parts[1];
    let gameId = 'a-plague-tale-innocence';
    if (prefix === 'REQU')
        gameId = 'a-plague-tale-requiem';
    if (prefix === 'OUTW')
        gameId = 'outward-2';
    if (prefix === 'DEMO')
        gameId = 'demo-game';
    if (prefix === 'RDR1')
        gameId = 'red-dead-redemption';
    if (prefix === 'STRA')
        gameId = 'stray';
    if (prefix === 'RE2R')
        gameId = 'resident-evil-2-remake';
    if (prefix === 'RLPA')
        gameId = 'rusty-lake-paradise';
    if (prefix === 'MAFI')
        gameId = 'mafia-definitive-edition';
    return { valid: true, gameId };
}
/**
 * Activates a license key for this specific PC
 */
function activateLicense(licenseKey, gameTitle) {
    const check = validateKeyFormat(licenseKey);
    if (!check.valid || !check.gameId) {
        return { success: false, message: check.error || "Noto'g'ri kalit" };
    }
    const hwidInfo = (0, hwid_1.getHardwareId)();
    const store = loadLicenseStore();
    const entry = {
        gameId: check.gameId,
        gameTitle,
        licenseKey: licenseKey.trim().toUpperCase(),
        hwid: hwidInfo.hwid,
        activatedAt: new Date().toISOString(),
        status: 'active',
    };
    store.licenses[check.gameId] = entry;
    saveLicenseStore(store);
    return {
        success: true,
        message: `${gameTitle} ushbu qurilma (${hwidInfo.formattedHwid}) uchun muvaffaqiyatli faollashtirildi!`,
        entry,
    };
}
/**
 * Check if a game is activated on this device
 */
function isGameActivated(gameId) {
    const store = loadLicenseStore();
    const entry = store.licenses[gameId];
    if (!entry)
        return false;
    return entry.status === 'active' && entry.hwid === (0, hwid_1.getHardwareId)().hwid;
}
