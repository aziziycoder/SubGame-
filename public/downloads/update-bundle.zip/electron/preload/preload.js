"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const api = {
    getHardwareId: () => electron_1.ipcRenderer.invoke('get-hwid'),
    getLicenses: () => electron_1.ipcRenderer.invoke('get-licenses'),
    activateLicense: (key, gameTitle) => electron_1.ipcRenderer.invoke('activate-license', { key, gameTitle }),
    selectGameExecutable: () => electron_1.ipcRenderer.invoke('select-game-exe'),
    launchGame: (config) => electron_1.ipcRenderer.invoke('launch-game', config),
    installSubtitle: (config) => electron_1.ipcRenderer.invoke('install-subtitle', config),
    openGameFolder: (exePath) => electron_1.ipcRenderer.invoke('open-game-folder', exePath),
    getSubtitleVersion: (gameId) => electron_1.ipcRenderer.invoke('get-subtitle-version', gameId),
    onStatusUpdate: (callback) => {
        const handler = (_, status) => callback(status);
        electron_1.ipcRenderer.on('game-status', handler);
        return () => {
            electron_1.ipcRenderer.removeListener('game-status', handler);
        };
    },
    windowControl: (action) => electron_1.ipcRenderer.send('window-control', action),
    openExternal: (url) => electron_1.ipcRenderer.send('open-external', url),
    getAppVersion: () => electron_1.ipcRenderer.invoke('get-app-version'),
    downloadUpdate: (url) => electron_1.ipcRenderer.invoke('download-update', url),
    applyUpdate: (tempPath) => electron_1.ipcRenderer.invoke('apply-update', tempPath),
    getUpdateInfo: () => electron_1.ipcRenderer.invoke('get-update-info'),
    onUpdateProgress: (callback) => {
        const handler = (_, progress) => callback(progress);
        electron_1.ipcRenderer.on('update-progress', handler);
        return () => {
            electron_1.ipcRenderer.removeListener('update-progress', handler);
        };
    },
};
electron_1.contextBridge.exposeInMainWorld('subgame', api);
